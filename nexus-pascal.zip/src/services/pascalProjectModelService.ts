import * as fs from 'fs';
import * as path from 'path';
import * as vscode from 'vscode';
import { readLazarusBuildModes } from '../providers/lazarus';
import {
    FpcBuildTarget,
    FpcProjectModel,
    LazarusBuildTarget,
    LazarusProjectModel,
    PascalBuildTarget,
    PascalProject
} from '../model/pascalProject';
import { DefaultBuildModeStorage } from '../providers/defaultBuildModeStorage';
import { FpcTaskDefinition, LazarusTaskDefinition } from '../providers/taskDefinitions';

export class PascalProjectModelService {
    public constructor(private readonly workspaceRoot: string) {
    }

    public loadProjects(): PascalProject[] {
        const projectsByFile = new Map<string, PascalProject>();
        const tasks = this.getConfiguredTasks();

        for (const taskDefinition of tasks) {
            if (taskDefinition.type === 'fpc') {
                this.collectFpcProject(taskDefinition, projectsByFile);
            } else if (taskDefinition.type === 'lazarus') {
                this.collectLazarusProject(taskDefinition, projectsByFile);
            }
        }

        const projects = Array.from(projectsByFile.values());
        this.applyDefaultTarget(projects);
        return projects;
    }

    public getDefaultTarget(projects: PascalProject[] = this.loadProjects()): PascalBuildTarget | undefined {
        for (const project of projects) {
            const target = project.targets.find(candidate => candidate.isDefault);
            if (target) {
                return target;
            }
        }

        return projects[0]?.targets[0];
    }

    public async setDefaultTarget(target: PascalBuildTarget): Promise<void> {
        if (target.kind === 'lazarus') {
            await this.setDefaultLazarusTarget(target);
            return;
        }

        await this.setDefaultFpcTarget(target);
    }

    private getConfiguredTasks(): any[] {
        return vscode.workspace
            .getConfiguration('tasks', vscode.Uri.file(this.workspaceRoot))
            .get<any[]>('tasks', []);
    }

    private collectFpcProject(taskDefinition: FpcTaskDefinition, projectsByFile: Map<string, PascalProject>): void {
        if (!taskDefinition.file) {
            return;
        }

        const cwd = this.resolveWorkspacePath(taskDefinition.cwd);
        const projectFile = this.resolveWorkspacePath(taskDefinition.file, cwd);
        const project = this.getOrCreateFpcProject(projectFile, taskDefinition, projectsByFile);
        const label = taskDefinition.label || project.label;

        project.targets.push({
            id: this.createTargetId(projectFile, label),
            kind: 'fpc',
            label,
            projectId: project.id,
            projectFile,
            isDefault: taskDefinition.group?.isDefault === true,
            isInProjectFile: false,
            taskDefinition
        });
    }

    private collectLazarusProject(taskDefinition: LazarusTaskDefinition, projectsByFile: Map<string, PascalProject>): void {
        if (!taskDefinition.project) {
            return;
        }

        const cwd = this.resolveWorkspacePath(taskDefinition.cwd);
        const projectFile = this.resolveWorkspacePath(taskDefinition.project, cwd);
        const project = this.getOrCreateLazarusProject(projectFile, projectsByFile);
        const buildMode = taskDefinition.buildMode || taskDefinition.label || 'Default';
        const label = taskDefinition.label || buildMode;

        this.addLazarusTarget(project, {
            id: this.createTargetId(projectFile, label, buildMode),
            kind: 'lazarus',
            label,
            projectId: project.id,
            projectFile,
            cwd: path.dirname(projectFile),
            buildMode,
            isDefault: taskDefinition.group?.isDefault === true,
            isInProjectFile: false,
            taskDefinition
        });

        for (const mode of readLazarusBuildModes(projectFile)) {
            this.addLazarusTarget(project, {
                id: this.createTargetId(projectFile, mode.name, mode.name),
                kind: 'lazarus',
                label: mode.name,
                projectId: project.id,
                projectFile,
                cwd: path.dirname(projectFile),
                buildMode: mode.name,
                isDefault: this.isDefaultLazarusTarget(projectFile, mode.name),
                isInProjectFile: true
            });
        }
    }

    private getOrCreateFpcProject(
        projectFile: string,
        taskDefinition: FpcTaskDefinition,
        projectsByFile: Map<string, PascalProject>
    ): FpcProjectModel {
        const existing = projectsByFile.get(projectFile);
        if (existing?.kind === 'fpc') {
            return existing;
        }

        const project: FpcProjectModel = {
            id: projectFile,
            kind: 'fpc',
            label: path.basename(taskDefinition.file || projectFile),
            file: projectFile,
            fileExists: fs.existsSync(projectFile),
            isDefault: false,
            targets: []
        };
        projectsByFile.set(projectFile, project);
        return project;
    }

    private getOrCreateLazarusProject(projectFile: string, projectsByFile: Map<string, PascalProject>): LazarusProjectModel {
        const existing = projectsByFile.get(projectFile);
        if (existing?.kind === 'lazarus') {
            return existing;
        }

        const project: LazarusProjectModel = {
            id: projectFile,
            kind: 'lazarus',
            label: path.basename(projectFile),
            file: projectFile,
            fileExists: fs.existsSync(projectFile),
            isDefault: false,
            targets: []
        };
        projectsByFile.set(projectFile, project);
        return project;
    }

    private addLazarusTarget(project: LazarusProjectModel, target: LazarusBuildTarget): void {
        const key = this.getLazarusTargetKey(target);
        if (project.targets.some(candidate => this.getLazarusTargetKey(candidate) === key)) {
            return;
        }

        project.targets.push(target);
    }

    private applyDefaultTarget(projects: PascalProject[]): void {
        let defaultTarget = this.getExplicitDefaultTarget(projects);

        if (!defaultTarget) {
            defaultTarget = projects[0]?.targets[0];
        }

        for (const project of projects) {
            project.isDefault = false;
            for (const target of project.targets) {
                target.isDefault = target === defaultTarget;
                if (target.isDefault) {
                    project.isDefault = true;
                }
            }
        }
    }

    private getExplicitDefaultTarget(projects: PascalProject[]): PascalBuildTarget | undefined {
        for (const project of projects) {
            const target = project.targets.find(candidate => candidate.isDefault);
            if (target) {
                return target;
            }
        }

        return undefined;
    }

    private getLazarusTargetKey(target: LazarusBuildTarget): string {
        return (target.buildMode || target.label).toLowerCase();
    }

    private isDefaultLazarusTarget(projectFile: string, label: string): boolean {
        return DefaultBuildModeStorage.getInstance().isDefaultBuildMode(`${projectFile}-${label}`);
    }

    private async setDefaultFpcTarget(target: FpcBuildTarget): Promise<void> {
        DefaultBuildModeStorage.getInstance().setDefaultBuildMode('');

        const tasks = this.getConfiguredTasks();
        let tasksUpdated = false;

        for (const task of tasks) {
            const taskType = String(task?.type).toLowerCase();
            if (taskType !== 'fpc' && taskType !== 'lazarus') {
                continue;
            }

            const isTargetTask = taskType === 'fpc'
                && task.label === target.label
                && this.resolveWorkspacePath(task.file, this.resolveWorkspacePath(task.cwd)) === target.projectFile;
            if (!task.group && !isTargetTask) {
                continue;
            }
            if (!task.group) {
                task.group = { kind: 'build' };
            }

            const desiredDefault = isTargetTask ? true : undefined;
            if (task.group.isDefault !== desiredDefault) {
                task.group.isDefault = desiredDefault;
                tasksUpdated = true;
            }
        }

        if (tasksUpdated) {
            await this.updateConfiguredTasks(tasks);
        }
    }

    private async setDefaultLazarusTarget(target: LazarusBuildTarget): Promise<void> {
        DefaultBuildModeStorage.getInstance().setDefaultBuildMode(`${target.projectFile}-${target.label}`);

        const tasks = this.getConfiguredTasks();
        let tasksUpdated = false;

        for (const task of tasks) {
            const taskType = String(task?.type).toLowerCase();
            if (taskType !== 'fpc' && taskType !== 'lazarus') {
                continue;
            }

            const isTargetTask = taskType === 'lazarus'
                && task.label === target.label
                && this.resolveWorkspacePath(task.project, this.resolveWorkspacePath(task.cwd)) === target.projectFile;

            if (!task.group && !isTargetTask) {
                continue;
            }
            if (!task.group) {
                task.group = { kind: 'build' };
            }

            if (typeof task.group === 'object' && task.group.isDefault !== (isTargetTask || undefined)) {
                task.group.isDefault = isTargetTask || undefined;
                tasksUpdated = true;
            }
        }

        if (tasksUpdated) {
            await this.updateConfiguredTasks(tasks);
        }
    }

    private async updateConfiguredTasks(tasks: any[]): Promise<void> {
        await vscode.workspace
            .getConfiguration('tasks', vscode.Uri.file(this.workspaceRoot))
            .update('tasks', tasks, vscode.ConfigurationTarget.WorkspaceFolder);
    }

    private createTargetId(projectFile: string, label: string, buildMode?: string): string {
        return `${projectFile}::${buildMode || label}`;
    }

    private resolveWorkspacePath(value: string | undefined, basePath: string = this.workspaceRoot): string {
        if (!value) {
            return basePath;
        }

        const resolved = value.replace(/\$\{workspaceFolder\}/g, this.workspaceRoot);
        if (path.isAbsolute(resolved)) {
            return resolved;
        }

        return path.resolve(basePath, resolved);
    }
}
